
import random
import math
#Ejercicio 1

"""totalDesc = 0
totalSinDesc = 0
precioConFinal = 0
precioSinFinal = 0
descuentoOpcion = ""

opciones = ["s", "n"]

nombre = input("Dame tu nombre: ")
while(not nombre.isalpha() or nombre == ""):
    print("El nombre no es válido")
    nombre = input("Dame tu nombre: ")

productos = input("Que cantidad de productos desea comprar?: ")
while(not productos.isdigit() or int(productos) <= 0):
    print("La cantidad de productos no es válida")
    productos = input("Que cantidad de productos desea comprar?: ")

for i in range(1, int(productos) + 1):
    print(f"Producto numero : {i}")
    precioProducto = ""
    while(not precioProducto.isdigit() or int(precioProducto) <= 0 or not descuentoOpcion.isalpha() or not descuentoOpcion.lower() in opciones ):
            precioProducto = input("Dame el precio del producto: ")
            descuentoOpcion = input("El producto tiene descuento? (s/n)")
    if(descuentoOpcion == "s"):
        descuento = float(precioProducto) * 0.10
        precioConFinal += (float(precioProducto) - descuento)
    else:
        precioConFinal += float(precioProducto)
    precioSinFinal += float(precioProducto)
print(f"Total sin descuentos: ${precioSinFinal}")
if(precioConFinal != precioSinFinal):
    print(f"Total con descuentos: ${precioConFinal}")
    print(f"Total ahorrado: ${precioSinFinal - precioConFinal}")
else:
     print(f"No hubo descuentos en los productos")
print(f"El promedio es: {(precioSinFinal / int(productos)):.2f}")

#Ejercicio 2

usuario = "alumno"
clave = "python123"
intentos = 1
salir = False
opcion = ""

print("Bienvenido al campus virtual!")
while(intentos <= 3):
    print(f"Intento {intentos}/3...")
    usuarioIngresado = input("Ingresa el usuario: ")
    claveIngresada = input("Ingresa la clave: ")
    if(claveIngresada == clave and usuarioIngresado == usuario):
         while(salir == False):
              print("Elije la opcion deseada: ")
              print("1. Ver estado de inscripcion")
              print("2. Cambiar contraseña")
              print("3. Ver mensaje motivacional")
              print("4. Salir")
              opcion = input("La opcion  elegir: ")
              if(opcion == "1"):
                   print("El estado de su inscripcion es: 'Inscripto'")
              elif(opcion == "2"):
                   claveIngresada = input("Introduce la clave: ")
                   if(claveIngresada != clave):
                        print("La clave no coincide")
                   else:
                        claveIngresada = input("Ingresa la nueva clave: ")
                        if(claveIngresada != "" and len(claveIngresada) >= 6):
                             clave = claveIngresada
                             print("Clave reestablecida exitosamente!")
                        else:
                             print("La clave debe tener al menos 6 caracteres")
              elif(opcion == "3"):
                   print("Tu puedes! Sigue adelante esforzandote!!")
              elif(opcion == "4"):
                   salir = True
                   intentos = 1
              else:
                   print("Error, opcion no válida")
    else: 
         intentos += 1
         print("Error, usuario o clave no vàlidos")
print("Cuenta Bloqueada, intenta mas tarde") """

#Ejercicio 3
"""
lunes = ["", "", "", ""]
martes = ["", "", ""]
salir = False

operador = input("Digame su nombre: ")
while(operador.isalpha and operador != "" and salir == False):
    print("Bienvenido al sistema de turnos del hospital!")
    print("Que opcion desea elegir: ")
    print("1) Reservar turno")
    print("2) Cancelar turno")
    print("3) Ver agenda del dia")
    print("4) Ver resumen del dia")
    print("5) Cerrar sistema")
    opcion = input("Que opcion deseas elegir: ")
    if(opcion == "1"):
        nombrePaciente = input("Dime el nombre del paciente a reservar: ")
        diaReserva = input("Que dia te gustaria que fuera la cita? (Lunes o Martes): ")
        if(diaReserva.lower() == "lunes"):
            for lugar in range(len(lunes)):
                lugaresOcupados = 0
                if(lunes[lugar] == ""):
                    lunes[lugar] = nombrePaciente
                    print("Cita agendada correctamente!")
                    break
                elif(lunes[lugar] != ""):
                    if(lunes[lugar].lower() == nombrePaciente.lower()):
                        print("Ese nombre ya esta agendado para el dia lunes")
                        break
                    lugaresOcupados += 1
                    if(lugaresOcupados == 4):
                        print("Dia lleno, intente otro dia")
            
        elif(diaReserva.lower() == "martes"):
             for lugar in range(len(martes)):
                if(martes[lugar] == ""):
                    martes[lugar] = nombrePaciente
                    print("Cita agendada correctamente!")
                    break
                elif(martes[lugar] != ""):
                    if(martes[lugar].lower() == nombrePaciente.lower()):
                        print("Ese nombre ya esta agendado para el dia martes")
                        break
                    lugaresOcupados += 1
                    if(lugaresOcupados == 3):
                        print("Dia lleno, intente otro dia")
        else:
            print("Dia no registrado")
    elif(opcion == "2"):
        nombrePaciente = input("Dime el nombre del paciente registrado en la cita: ")
        diaCita = input("Que dia tenia registrado la cita: ")
        if(diaCita.lower() == "lunes" or diaCita.lower() == "martes"):
          if(nombrePaciente in lunes):
            opcionS = input("Desea eliminar la cita para el dia lunes de parte de " + nombrePaciente + "? (s/n): ")
            if(opcionS == "s"):
                for dia in range(len(lunes)):
                    if(lunes[dia].lower() == nombrePaciente.lower()):
                        lunes[dia] = ""
                        print("Cita eliminada exitosamente!")
                        break
            elif(opcionS == "n"):
                print("Operacion cancelada con exito")
            else: 
                print("Opcion no válida")
          else:
              print(f"No se encuentra ningun paciente con el nombre de '{nombrePaciente}' par el dia lunes")
        if(nombrePaciente in martes):
            opcionS = input("Desea eliminar la cita para el dia martes de parte de " + nombrePaciente + "? (s/n): ")
            if(opcionS == "s"):
                for dia in range(len(martes)):
                    if(martes[dia].lower() == nombrePaciente.lower()):
                        martes[dia] = ""
                        print("Cita eliminada exitosamente!")
                        break
            elif(opcionS == "n"):
                print("Operacion cancelada con exito")
            else: 
                print("Opcion no válida")
        else:
              print(f"No se encuentra ningun paciente con el nombre de '{nombrePaciente}' par el dia martes")
    elif(opcion == "3"):
            for i in range(len(lunes)):
                print(f"Turno n° {i + 1} del dia Lunes")
                if(lunes[i] == ""):
                    print("Libre")
                else:
                    print(f"Paciente: {lunes[i]}")
            for i in range(len(martes)):
                print(f"Turno n° {i + 1} del dia Martes")
                if(martes[i] == ""):
                    print("Libre")
                else:
                    print(f"Paciente: {martes[i]}")
    elif(opcion == "4"):
        contadorLibreL = 0
        contadorOcupadoL = 0
        print("Turnos del dia Lunes")
        for i in range(len(lunes)):
            if(lunes[i] == ""):
                contadorLibreL += 1
            else:
                contadorOcupadoL += 1
        print(f"Turnos libres: {contadorLibreL}")
        print(f"Turnos ocupados: {contadorOcupadoL}")
        print("Turnos del dia Martes")
        contadorLibreM = 0
        contadorOcupadoM = 0
        for i in range(len(martes)):
            if(martes[i] == ""):
                contadorLibreM += 1
            else:
                contadorOcupadoM += 1
        print(f"Turnos libres: {contadorLibreM}")
        print(f"Turnos ocupados: {contadorOcupadoM}")
        if(contadorOcupadoM > contadorOcupadoL):
            print("EL dia martes tiene mas turnos ocupados que el lunes")
        elif(contadorOcupadoL == contadorOcupadoM):
            print("El dia martes tiene la misma cantidad de turnos que el lunes")
        else:
            print("El dia lunes tiene mas turnos ocupados que el martes")
    elif(opcion == "5"):
        salir= True
        print("Hasta la proxima!") """

#Ejercicio 4
# energia = 100
# tiempo = 12
# cerraduras_abiertas = 0
# alarma = False
# codigo_parcial = ""
# vecesForzar = 0
# nombre = "0"

# while(not nombre.isalpha()):
#     nombre = input("Dame tu nombre: ")
# while(energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and alarma == False):
#  if(energia > 100): energia = 100

#  print(f"Sus datos: -Energia: {energia}  -Tiempo: {tiempo}  -Cerraduras abiertas: {cerraduras_abiertas}")
#  print("Que desea hacer agente?: ")
#  if(energia < 40): print("1. Forzar cerradura (-20 energia, -2 tiempo) Hay riesgo de alarma!")
#  else: print("1. Forzar cerradura (-20 energia, -2 tiempo)")
#  print("2. Hackear panel (-10 energia, -3 tiempo)")
#  print("3. Descansar (+15 energia, -1 tiempo)")
#  opcion = input("Que opcion eliges agente?: ")
#  if(opcion.isdigit()):
#      if(opcion == "1"):
#          energia -= 20
#          tiempo -= 2
#          if(vecesForzar == 2):
#              print("Demasiados intentos de forzado, se bloqueo la cerradura!")
#              print("La alarma se activo!")
#              alarma = True
#          else:
#              if(energia <= 40):
#                  numeroRandom = random.randint(1,3)
#              else:
#                  numeroRandom = random.randint(1, 4)
#              numeroAgente = input("Elige un numero del 1 al 4!: ")

#              if(not numeroAgente.isdigit() or int(numeroAgente) < 1 or int(numeroAgente) > 4 ): 
#                  print("Numero no valido")
#              else:
#                 if(numeroRandom == int(numeroAgente)):
#                     print("Alarma activada!")
#                     alarma = True
#                 else: 
#                     print("Abriste una cerradura!")
#                     cerraduras_abiertas += 1
#                     vecesForzar += 1
#      if(opcion == "2"):
#          vecesForzar = 0
#          energia -= 20
#          tiempo -= 3
#          letra = ""
#          print("Debes descifrar el codigo!")
#          for i in range(4):
#              print("Suma una letra al codigo final!")
#              letra = input("Ingresa una letra: ")
#              if(len(letra) != 1 or not letra.isalpha()):
#                  print("Letra no válida, perdiste el turno")
#              else:
#                  codigo_parcial += letra
#                  print("Letra guardada correctamente")
#                  if(len(codigo_parcial) >= 8):
#                     print("Abriste una cerradura! ")
#                     cerraduras_abiertas += 1
#                     codigo_parcial = 0
#      if(opcion == "3"):
#         if(energia < 100):
#             energia += 15
#             tiempo -= 1
#         else:
#             print("Energia llena!")
#      else:
#          print("Opcion no válida")

# if(cerraduras_abiertas == 3):
#     print("Felicidades, lograste escapar agente!")
# else:
#     print("GAME OVER, no pudiste salir a tiempo")
#Ejercicio 5

nombre = ""
vidaJugador = 100
vidaEnemigo = 100
pocionesVida = 3
dañoBase = 15
dañoBaseEnem = 12
turnoGladiador = True

while(not nombre.isalpha() or len(nombre) == 0):
    nombre = input("Dime tu nombre guerrero!: ")
    if(not nombre.isalpha()):
        print("Nombre no válido, solo se aceptan letras")
       
print(f"===INICIO DEL COMBATE===")
while(vidaJugador > 0 and vidaEnemigo > 0):
    if(turnoGladiador == True):
        if(vidaJugador > 100):
            vidaJugador = 100
        print(f"===TURNO DE {nombre}===")
        print(f"{nombre} HP: {vidaJugador}   Enemigo: {vidaEnemigo}   Pociones: {pocionesVida}")
        print("1. Ataque pesado")
        print("2. Rafaga Veloz")
        print("3. Curar")
        opcion = input("Que opcion elige?: ")
        if(opcion.isdigit()):
            if(opcion == "1"):
                if(vidaEnemigo < 20):
                    dañoBase = 15 * 1.5
                    vidaEnemigo -= dañoBase
                    print("Haz acertado un golpe critico!")
                else:
                    vidaEnemigo -= dañoBase
                turnoGladiador = False
                print(f"{nombre} ha acertado un golpe de {dañoBase} de daño")
            elif(opcion == "2"):
                for i in range(3):
                    print("Haz acertado un golpe de 5 de daño!")
                    vidaEnemigo -= 5
                turnoGladiador = False
            elif(opcion == "3"):
                if(pocionesVida > 0):
                    if(vidaJugador < 100):
                         print("Haz recuperado 30!")
                         vidaJugador += 30
                         pocionesVida -= 1
                else:
                    print("No tienes pociones!")
                turnoGladiador = False
            else:
                print("Opcion no válida")
    else:
        print("===TURNO DE ENEMIGO===")
        print("El enemigo ha acertado un golpe de 12 de daño!")
        vidaJugador -= 12
        turnoGladiador = True
if(vidaJugador <= 0):
    print("DERROTA. Haz caido en la arena")
elif(vidaEnemigo <= 0):
    print(f"VICTORIA. {nombre} ha ganado la batalla!")
            

